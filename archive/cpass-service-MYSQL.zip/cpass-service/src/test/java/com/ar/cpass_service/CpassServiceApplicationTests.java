package com.ar.cpass_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpassServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
