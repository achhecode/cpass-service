package com.ar.cpass_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpassServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpassServiceApplication.class, args);
	}

}
