-- Insert organizations
INSERT INTO organization (name, industry) VALUES ('OpenAI', 'AI Research');
INSERT INTO organization (name, industry) VALUES ('Google', 'Tech');
INSERT INTO organization (name, industry) VALUES ('Amazon', 'E-Commerce');

-- Insert users
INSERT INTO users (username, email, organization_id) VALUES ('john_doe', 'john@example.com', 1);
INSERT INTO users (username, email, organization_id) VALUES ('alice_w', 'alice@example.com', 2);
INSERT INTO users (username, email, organization_id) VALUES ('bob_k', 'bob@example.com', 3);

-- Insert employees
INSERT INTO employee (name, role, salary, organization_id) VALUES ('Jane Smith', 'Engineer', 90000, 1);
INSERT INTO employee (name, role, salary, organization_id) VALUES ('Tom Brown', 'Manager', 110000, 2);
INSERT INTO employee (name, role, salary, organization_id) VALUES ('Sara Lee', 'Analyst', 75000, 3);
