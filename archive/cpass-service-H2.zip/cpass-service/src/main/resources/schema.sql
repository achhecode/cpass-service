DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS employee;
DROP TABLE IF EXISTS organization;

CREATE TABLE organization (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    industry VARCHAR(100)
);

CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    organization_id BIGINT,
    FOREIGN KEY (organization_id) REFERENCES organization(id)
);

CREATE TABLE employee (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(50),
    salary DOUBLE,
    organization_id BIGINT,
    FOREIGN KEY (organization_id) REFERENCES organization(id)
);
